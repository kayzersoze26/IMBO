function [bestcost,alphabonobo,convergence_curve]=IMBO(N,d,Var_min,Var_max,max_it,CostFunction,bonobo,D,ii,intertia)
p_xgm_initial=0.03;%0.03; % Initial probability for extra-group mating (generally 1/d for higher dimensions)
scab=1.25;  %Sharing cofficient for alpha bonobo (Generally 1-2)
scsb=1.3;   % Sharing coefficient for selected bonobo(Generally 1-2)
rcpp=0.0035;%0.0035; % Rate of change in  phase probability (Generally 1e-3 to 1e-2)
tsgs_factor_max=0.05;% Max. value of temporary sub-group size factor

%% Initialization
max_it=max_it*N;
cost=zeros(N,1);

for i=1:N
%     bonobo(i,:)=unifrnd(Var_min,Var_max,[1 d]);
    cost(i) = CostFunction(D,round(bonobo(i,:)));
end
[bestcost,ID]=min(cost);
alphabonobo=bonobo(ID,:); % Best solution found in the population
pbestcost=bestcost;% Initialization of previous best cost
npc=0; % Negative phase count
ppc=0; % Positive phase count
p_xgm=p_xgm_initial; % Probability for extra-group mating
tsgs_factor_initial=0.5*tsgs_factor_max; % Initial value for temporary sub-group size factor
tsgs_factor=tsgs_factor_initial; % Temporary sub-group size factor
p_p=0.5; % Phase probability
p_d=0.5; % Directional probability

   it=N;   
  
while(it<max_it)

    tsgs_max=max(2,ceil(N*tsgs_factor));  % Maximum size of the temporary sub-group
      a1 = 2+rand();
      teta = rand();
    for i=1:N
         R = abs(cos(a1.*acos(teta)));
         teta = R;
         w1=2*exp(-(4*it/max_it)^3);
        newbonobo=zeros(1,d);
        B = 1:N;
        B(i)=[];
        %% Determining the actual size of the temporary sub-group
        tsg=randi([2 tsgs_max]);
        %% Selection of pth Bonobo using fission-fusion social strategy & flag value determination
        q=randsample(B,tsg);
        temp_cost=cost(q);
        [~,ID1]=min(temp_cost);
        p=q(ID1);
        if(cost(i)<cost(p))
            p=q(randi([1 tsg]));
            flag=1;
        else
            flag=-1;
        end
        %% Creation of newbonobo


        
        if(rand<=p_p)
            r1=rand(1,d); %% Promiscuous or restrictive mating strategy
            newbonobo=bonobo(i,:)+scab*r1.*(alphabonobo-bonobo(i,:))+flag*scsb*(1-r1).*(bonobo(i,:)-bonobo(p,:));
        else
            for j=1:d
                if(rand<=p_xgm)
                    rand_var=rand; %% Extra group mating strategy

%                      R = abs(cos(a1.*acos(rand)));
%                     rand_var=R;
                    if(alphabonobo(1,j)>=bonobo(i,j))
                        if(rand<=(p_d))
                            beta1=exp(((rand_var)^2)+rand_var-(2/rand_var));
                            newbonobo(1,j)=bonobo(i,j)+beta1*(Var_max(j)-bonobo(i,j));
                        else
                            beta2=exp((-((rand_var)^2))+(2*rand_var)-(2/rand_var));
                            newbonobo(1,j)=bonobo(i,j)-beta2*(bonobo(i,j)-Var_min(j));
                        end
                    else
                        if(rand<=(p_d))
                            beta1=exp(((rand_var)^2)+(rand_var)-2/rand_var);
                            newbonobo(1,j)=bonobo(i,j)-beta1*(bonobo(i,j)-Var_min(j));
                        else
                            beta2=exp((-((rand_var)^2))+(2*rand_var)-2/rand_var);
                            newbonobo(1,j)=bonobo(i,j)+beta2*(Var_max(j)-bonobo(i,j));
                        end
                    end
                else
                    if((flag==1)||(rand<=p_d)) %% Consortship mating strategy
                        newbonobo(1,j)=bonobo(i,j)+flag*(exp(-rand))*(bonobo(i,j)-bonobo(p,j));
                    else
                        newbonobo(1,j)=bonobo(p,j);
                    end
                end
            end
        end
        %% Clipping
        for j=1:d
            if(newbonobo(1,j)>Var_max(j))
                newbonobo(1,j)=Var_max(j);
            end
            if(newbonobo(1,j)<Var_min(j))
                newbonobo(1,j)=Var_min(j);
            end
        end
        newcost = CostFunction(D,round(newbonobo)); % New cost evaluation
         it=it+1;
        %% New bonobo acceptance criteria
        if((newcost<cost(i))||(rand<=(p_xgm)))
            cost(i)=newcost;
            bonobo(i,:)=newbonobo;
            if(newcost<bestcost)
                bestcost=newcost;
                alphabonobo=newbonobo;
            end
        end
    end
    %% Parameters updation
    if(bestcost<pbestcost)
        npc=0; %% Positive phase
        ppc=ppc+1;
        cp=min(0.5,(ppc*rcpp));
        pbestcost=bestcost;
        p_xgm=p_xgm_initial;
        p_p=0.5+cp;
        p_d=p_p;
        tsgs_factor=min(tsgs_factor_max,(tsgs_factor_initial+ppc*(rcpp^2)));
    else
        npc=npc+1; %% Negative phase
        ppc=0;
        cp=-(min(0.5,(npc*rcpp)));
        p_xgm=min(0.5,p_xgm_initial+npc*(rcpp^2));
        tsgs_factor=max(0,(tsgs_factor_initial-npc*(rcpp^2)));
        p_p=0.5+cp;
        p_d=0.5;
    end





    for i= 1:N
        RandIndexZ = randperm(d);
        index1 = RandIndexZ(1);
        index2 = RandIndexZ(2);
        %%
        switch intertia
        case 1
%         disp('Butterworth intertia weight')
        wmin=0.4;
        wmax=0.5;
        p1=max_it/3;
        p2=10;
        w=wmax*1/(1+(it/p1)^p2)+wmin;

         case 2
%         disp('Simulated annealing intertia weight')
        wmin=0.5;
        wmax=0.9;
        p=0.95;
        r=rand;
        w=(wmax-wmin)*p^(it-1)+wmin;

          case 3
%         disp('Exponential decresing intertia weight')
        wmin=0.4;
        wmax=0.95;
        w=(wmax-wmin)*exp(-10*it/max_it)+wmin;

         case 4
%         disp('Logarithmic decresing intertia weight')
        wmin=0.25;
        wmax=0.9;
        w=(wmax-wmin)*log((1+10*it)/max_it)+wmin;

        case 5
%         disp('Sigmoid decresing intertia weight')
        wmin=0.4;
        wmax=0.9;
        r=rand;
        u=10^(log(max_it)-2);
        w=(wmin-wmax)/(1+exp(-u*(it-r*max_it)))+wmax;

         case 6
%         disp('Sigmoid increasing intertia weight')
        wmin=0.4;
        wmax=0.9;
        r=rand;
        u=10^(log(max_it)-2);
        w=(wmin-wmax)/(1+exp(u*(it-r*max_it)))+wmax;

        case 7
%         disp('Oscilaitng intertia weight')
        
        wmin=0.3;
        wmax=0.7;
        k=7;
        S1=3*max_it/4;
        T=2*S1/(3+2*k);
        if it>S1
            w=wmin;
        else
            w=(wmin+wmax)/2+(wmax-wmin)*cos(2*pi*it/T)/2;
        end

        case 8
%         disp('Linearly decresing intertia weight')
        wmin=0.4;
        wmax=0.9;
        w=(wmin-wmax)*((max_it-it)/max_it)+wmax;

        case 9
%         disp('Nonlinear time variant intertia weight')
        wmin=0.4;
        wmax=0.9;
        w=(wmax-wmin)*((max_it-it)/max_it)^2+wmin;



        end

        %%
        
         MSv = bonobo(i,:);
         MSv(index1) = w.*bonobo(i,index1) + (1 - w).*bonobo(i,index2);


        Flag_UB=MSv>Var_max; % check if they exceed (up) the boundaries
        Flag_LB=MSv<Var_min; % check if they exceed (down) the boundaries
        MSv=(MSv.*(~(Flag_UB+Flag_LB)))+Var_max.*Flag_UB+Var_min.*Flag_LB;
        
        fitv = CostFunction(D,round(MSv));
        it=it+1;
        if(fitv < cost(i))
            bonobo(i,:) = MSv;
            cost(i) = fitv;
        end
    end
    %%

    
   disp(['Run no ' num2str(ii) ':Iteration ' num2str(it) ': Best Cost = ' num2str(bestcost)]);

    convergence_curve(it)=bestcost;
   
end



