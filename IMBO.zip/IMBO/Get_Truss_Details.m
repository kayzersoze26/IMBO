
function [D,Fobj] = Get_Truss_Details(F)

addpath('Functions\')


switch F

    case 'Model 2023'
        trussn='Model 2023';
        %Optimization Parameters  (Unit N - mm)
        ng = 284;
        ngshape=0;
        ngsize=284;
        LB =[ones(1,ngsize) ];
        UB =ones(1,ngsize).*37 ;
        plotmodel=0;
        Fobj=@fitness2023;
    case 'Model 2022'     %
        %Optimization Parameters  (Unit N - mm)
        trussn='Model 2022';
        ng = 336;
        ngshape=0;
        ngsize=336;
        LB =[ones(1,ngsize) ];
        UB =ones(1,ngsize).*37 ;
        plotmodel=0;
        Fobj=@fitness2022;

    case 'Model 2021'  
        trussn='Model 2021';  %
        %Optimization Parameters  (Unit N - mm)
        ng = 345;
        ngshape=0;
        ngsize=345;
        LB =[ones(1,ngsize) ];
        UB =ones(1,ngsize).*37 ;
        plotmodel=0;
        Fobj=@fitness2021;

    case 'Model 2019'
        trussn='Model 2019';
        %Optimization Parameters  (Unit N - mm)
        ng = 270;
        ngshape=10;
        ngsize=260;
        LB =[ones(1,ngsize) ones(1,ngshape).*-25000];
        UB =[ones(1,ngsize).*37 ones(1,ngshape).*3500];
        plotmodel=0;
        Fobj=@fitness2019;


    case 'Model 2018'
        trussn='Model 2018';
        %Optimization Parameters  (Unit N - mm)
        ng = 328;
        ngshape=14;
        ngsize=314;
        LB =[ones(1,ngsize) ones(1,ngshape).*9000];
        UB =[ones(1,ngsize).*37 ones(1,ngshape).*20000];
        plotmodel=0;
        Fobj=@fitness2018;

    case 'Model 2017'
        trussn='Model 2017';
        %Optimization Parameters  (Unit N - mm)
        ng = 211;
        ngshape=13;
        ngsize=198;
        LB =[ones(1,ngsize) ones(1,6).*25000 ones(1,7).*-12000];
        UB =[ones(1,ngsize).*37 ones(1,6).*35000 ones(1,7).*3000];
        plotmodel=0;
        Fobj=@fitness2017;



    case 'Model 2016'
        trussn='Model 2016';
        %Optimization Parameters  (Unit N - mm)
        ng = 124;
        ngshape=7;
        ngsize=117;
        LB =[ones(1,ngsize) ones(1,ngshape).*1000];
        UB =[ones(1,ngsize).*37 ones(1,ngshape).*3500];
        plotmodel=0;
        Fobj=@fitness2016;



    case 'Model 2015'
        trussn='Model 2015';
        %Optimization Parameters  (Unit N - mm)
        ng = 54;
        ngshape=9;
        ngsize=45;
        LB =[ones(1,ngsize) ones(1,ngshape).*100];
        UB =[ones(1,ngsize).*37 ones(1,ngshape).*1400];
        plotmodel=0;
        Fobj=@fitness2015;




end


D=struct('ng',ng,'UB',UB,'LB',LB,'ngsize',ngsize,'ngshape',ngshape,'plotmodel',plotmodel,'trussn',trussn);


end

function [fval]=fitness2023(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2023(XX(1:D.ngsize), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end

function [fval]=fitness2022(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2022(XX(1:D.ngsize), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end



function [fval,  StressVio, DispVio ]=fitness2021(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2021(XX(1:D.ngsize), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end


function [fval]=fitness2019(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2019(XX(1:D.ngsize),  XX(D.ngsize+1:end), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end

function [fval]=fitness2018(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2018(XX(1:D.ngsize),  XX(D.ngsize+1:end), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end

function [fval]=fitness2017(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2017(XX(1:D.ngsize),  XX(D.ngsize+1:end), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV)^2;

end

function [fval]=fitness2016(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2016(XX(1:D.ngsize),  XX(D.ngsize+1:end), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end

function [fval]=fitness2015(D,XX)



[W,  StressVio, DispVio ] = ISCSO_2015(XX(1:D.ngsize),  XX(D.ngsize+1:end), D.plotmodel);
TV=StressVio+DispVio;
fval=W*(1+TV);

end










