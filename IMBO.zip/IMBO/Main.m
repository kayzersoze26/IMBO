clear all;clc

names={'Model 2019'};

DATA_TRUSS = numel(names); 
addpath("Algorithms\")
Algorithm_name='IMBO';



            
np=50; % Number of search agents
Maxiteration =2000;



runno=1;
rr=randi(1000);

    for intertia=1:9
 I = 1;
    nut=cell2str(names(1,I));
    nut = nut(3:12);
 fprintf(' \n\n----- TRUSS = %s -----\n', nut)
[D,fobj]=Get_Truss_Details(nut);

for    ii=1:runno


    for i=1:np
        X(i,1:D.ng)=(D.LB+rand.*(D.UB-D.LB));
    end
    




    X(:,1:D.ngsize)=round(X(:,1:D.ngsize));
    
    % = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

    Graphplot=0;
    falg=str2func(Algorithm_name);

    [Score,Best_pos,convergence_curve]=falg(np,D.ng,D.LB,D.UB,Maxiteration,fobj,X,D,ii,intertia);




    Optrunfval{ii,:}{aa,intertia}=Score;
    Optrunbestpos{ii,:}{aa,intertia}=round(Best_pos);
    Optrun{ii,:}{aa,intertia}=convergence_curve;


end
    filepath_=['Results\'];
    name= [filepath_ 'ID_no_' num2str(rr) '_' nut '_' Algorithm_name '_np_' num2str(np) '_maxit_' num2str(Maxiteration) '_FDB_' num2str(aa) '_Inertia_' num2str(intertia) '.mat'];

    save(name);
   end

